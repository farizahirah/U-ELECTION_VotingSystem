<?php

namespace App\Http\Controllers;

use App\Models\Vote;
use App\Models\VoteDetail;
use Illuminate\Http\Request;
use App\Models\Candidate;
use Illuminate\Support\Facades\Auth;


class VoteController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $votes = VoteDetail::paginate(50);
        return view('vote.index', compact('votes'));
    }

    public function vote($id)
    {
        $candidates = Candidate::paginate(50);
        return view('vote.vote', compact('candidates', 'id'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('vote.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        VoteDetail::create([
            'title' => $request->title,
            'start' => $request->start,
            'end' => $request->end,
        ]);

        return redirect(route('vote.index'));
    }

    public function storeVoting(Request $request)
    {
        if(count($request->vote) > 3)
        {
            return back();
        }
        $user = Auth::user()->id;

        foreach($request->vote as $key=>$ci)
        {
            Vote::create([
                'user_id' => $user,
                'vote_id' => $request->vote_detail,
                'candidate_id' => $request->vote[$key],
                'total_vote' => 1,
            ]);
        }

        return redirect(route('result.index'));
    }



    /**
     * Display the specified resource.
     */
    public function show(Vote $vote)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(VoteDetail $vote)
    {
        return view('vote.edit', compact("vote"));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, VoteDetail $vote)
    {
        $vote->update([
            'title' => $request->title,
            'start' => $request->start,
            'end' => $request->end,
        ]);

        return redirect(route('vote.index'));
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Vote $vote, $id)
    {
        $sample = VoteDetail::destroy($id);

        // Redirect to the group management page
        return redirect(route('vote.index'));
    }

    public function result()
    {
        $vote_details = VoteDetail::get();
        $candidates = Candidate::get();

        foreach($vote_details as $key => $vd)
        {
            $candidate = Candidate::count();
            $vote = Vote::where('vote_id',$vd->id)->count();
            $candidate_voter = Vote::select('candidate_id')->selectRaw('count(candidate_id) as qty')->where('vote_id',$vd->id)->groupBy('candidate_id')->get();
            $user_voter = Vote::select('user_id')->selectRaw('count(user_id) as qty')->where('vote_id',$vd->id)->groupBy('user_id')->get();

            $vote_details[$key]->total_candidate = $candidate;
            $vote_details[$key]->total_vote = $vote;
            $vote_details[$key]->total_voter = count($user_voter);
            $vote_details[$key]->user_vote = $user_voter;
            $vote_details[$key]->candidate_vote = $candidate_voter;
        }
        return view('vote.result.index', compact('vote_details', 'candidates'));
    }
}
