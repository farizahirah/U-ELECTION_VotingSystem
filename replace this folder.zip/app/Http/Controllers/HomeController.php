<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\VoteDetail;
use App\Models\Candidate;
use App\Models\Vote;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $vote_details = VoteDetail::get();
        $candidates = Candidate::get();

        foreach($vote_details as $key => $vd)
        {
            $candidate = Candidate::count();
            $vote = Vote::where('vote_id',$vd->id)->count();
            $candidate_voter = Vote::select('candidate_id')->selectRaw('count(candidate_id) as qty')->where('vote_id',$vd->id)->groupBy('candidate_id')->get();
            $user_voter = Vote::select('user_id')->selectRaw('count(user_id) as qty')->where('vote_id',$vd->id)->groupBy('user_id')->get();

            $vote_details[$key]->total_candidate = $candidate;
            $vote_details[$key]->total_vote = $vote;
            $vote_details[$key]->total_voter = count($user_voter);
            $vote_details[$key]->user_vote = $user_voter;
            $vote_details[$key]->candidate_vote = $candidate_voter;
        }
        // dd("hehe");
        return view('dashboard', compact('vote_details', 'candidates'));
    }
}
