@extends('layouts.app', ['activePage' => 'dashboard', 'title' => 'U-Election', 'navName' => 'Dashboard', 'activeButton' => 'laravel'])

@section('content')
    <div class="content">
        <div class="container-fluid">
            @foreach ($vote_details as $vd)
            <div class="row">
                <div class="col-md-4">
                    <div class="card ">
                        <div class="card-header ">
                            <h4 class="card-title">{{ __('Total Votes') }}</h4>
                            <p class="card-category">{{ __('How many Vote') }}</p>
                        </div>
                        <div class="card-body text-center">
                            <h2>{{$vd->total_vote}}</h2>
                        </div>
                        <div class="card-footer">
                            <hr>
                            <div class="stats">
                                <p>Start: {{date('d-m-Y', strtotime($vd->start))}}, End: {{date('d-m-Y', strtotime($vd->end))}}</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card ">
                        <div class="card-header ">     
                            <h4 class="card-title">{{ __('Total Voters') }}</h4>
                            <p class="card-category">{{ __('How many Voter') }}</p>
                        </div>
                        <div class="card-body text-center">
                            <h2>{{$vd->total_voter}}</h2>
                        </div>
                        <div class="card-footer">
                            <hr>
                            <div class="stats">
                                <p>Start: {{date('d-m-Y', strtotime($vd->start))}}, End: {{date('d-m-Y', strtotime($vd->end))}}</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card ">
                        <div class="card-header ">
                            <h4 class="card-title">{{ __('Total Candidates') }}</h4>
                            <p class="card-category">{{ __('How many Candidate') }}</p>
                        </div>
                        <div class="card-body text-center">
                            <h2>{{$vd->total_candidate}}</h2>
                        </div>
                        <div class="card-footer">
                            <hr>
                            <div class="stats">
                                <p>Start: {{date('d-m-Y', strtotime($vd->start))}}, End: {{date('d-m-Y', strtotime($vd->end))}}</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="card ">
                        <div class="card-header ">
                            <h4 class="card-title">{{ $vd->title }}</h4>
                            <p class="card-category">{{ __('Live Result') }}</p>
                        </div>
                        <div class="card-body ">
                            <div id="chartActivity_{{$vd->id}}" class="ct-chart"></div>
                        </div>
                        <div class="card-footer ">
                            <div class="stats">
                                <i class="fa fa-check"></i> {{ __('Data information certified') }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
@endsection

@push('js')
    <script type="text/javascript">
        $(document).ready(function() {
            // Javascript method's body can be found in assets/js/demos.js
            @foreach($vote_details as $v)
            setTimeout(() => {
                var candidate = [];
                var count_vote = [];
                initDashboardPageCharts();
                    
                @foreach($candidates as $c)
                    candidate.push("<?php echo $c->user->name ?>");
                @endforeach
                
                @foreach($v->candidate_vote as $sv)
                    count_vote.push("<?php echo $sv->qty ?>");
                @endforeach
                
                function initDashboardPageCharts() {
                    var data = {
                        labels: candidate,
                        series: [
                            count_vote
                        ]
                    };

                    var options = {
                        seriesBarDistance: 10,
                        axisX: {
                            showGrid: false,
                        },
                        height: "245px",
                    };

                    var responsiveOptions = [
                        ['screen and (max-width: 640px)', {
                            seriesBarDistance: 5,
                            axisX: {
                                labelInterpolationFnc: function(value) {
                                    return value[0];
                                }
                            }
                        }]
                    ];

                    var chartActivity = Chartist.Bar('#chartActivity_<?php echo $v->id ?>', data, options, responsiveOptions);


                }
            }, 100);
            @endforeach
        });
    </script>
@endpush